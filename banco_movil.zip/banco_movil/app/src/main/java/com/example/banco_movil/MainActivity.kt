package com.example.banco_movil

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    private val irAAutenticacion = Runnable {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val logo = findViewById<ImageView>(R.id.logo)
        logo.startAnimation(AnimationUtils.loadAnimation(this, R.anim.subir_logo))
    }

    override fun onStart() {
        super.onStart()
        handler.postDelayed(irAAutenticacion, 2000)
    }

    override fun onStop() {
        handler.removeCallbacks(irAAutenticacion)
        super.onStop()
    }
}
